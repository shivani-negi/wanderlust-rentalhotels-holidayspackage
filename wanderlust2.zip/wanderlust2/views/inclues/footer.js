<footer>
    <div class="f-info">
        <div class="f-info-socials">
            <i class="fa-brands fa-facebook"></i>
    <i class="fa-brands fa-square-instagram"></i>
    <i class="fa-brands fa-linkedin"></i>
        </div>
            <div class="f-info-brand">&copy;Wanderlust private limited</div>
<div class="f-info-links">
    <a href="/privacy">Privacy</a>
    <a href="/terms">Terms</a>
    
</div>

      
    </div>
</footer>