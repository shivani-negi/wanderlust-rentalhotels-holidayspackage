const mongoose=require("mongoose");
const Schema=mongoose.Schema;
const passportLocalMongoose=require("passport-local-mongoose");
const userSchema=new Schema({
    email:{
        type:String,
        required:true,
    }
})
//user name or passport passport local mongoose automatically save kra deta h hmhare liye
userSchema.plugin(passportLocalMongoose);//username,hashing,salting or passport automatically implement ho jate h
module.exports=mongoose.model('User',userSchema);